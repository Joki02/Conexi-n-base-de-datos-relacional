import java.sql.{Connection, DriverManager, ResultSet}

object ConexionPeliculas {
  def main(args: Array[String]): Unit = {
    // Detalles de la conexión
    val url = "jdbc:mysql://localhost:3306/peliculas_db"
    val user = "USER"
    val password = "" // Dejo vacio porque me 

    var connection: Connection = null

    try {
      // Establecer conexión
      connection = DriverManager.getConnection(url, user, password)
      println("Conexión exitosa a la base de datos!")

      // Crear y ejecutar una consulta
      val statement = connection.createStatement()
      val resultSet: ResultSet = statement.executeQuery("SELECT * FROM peliculas")

      // Mostrar los resultados
      println("Películas en la base de datos:")
      while (resultSet.next()) {
        val id = resultSet.getInt("id_pelicula")
        val genero = resultSet.getString("genero")
        val titulo = resultSet.getString("titulo")
        println(s"ID: $id, Género: $genero, Título: $titulo")
      }
    } catch {
      case e: Exception =>
        e.printStackTrace()
    } finally {
      if (connection != null) {
        connection.close()
        println("Conexión cerrada.")
      }
    }
  }
}
